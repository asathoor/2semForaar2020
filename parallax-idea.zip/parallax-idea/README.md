JavaScript Boilerplates
=======================

In this directory you'll find several JavaScript boilterplates.

* jsBoilerplate.html: Vanilla JavaScript
